import controleur.*;

public class principal {

	public static void main(String[] args) {
		
		CtrlAccueil monCtrl= new CtrlAccueil(); 
		monCtrl.newDlgAccueil();
	}
}
